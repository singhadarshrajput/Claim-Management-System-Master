

/*INSERT INTO hospital(HID, Name, Location) VALUES ('H101', 'Apollo Hospital','Bangalore');
INSERT INTO member_policy(MID, PID, tenure,premium_last_date,subscription_date ) VALUES ('M101','P102',5,'2023-02-01','2022-02-01');
INSERT INTO benefits(BID, Name) VALUES ('B101','Accident Coverage');*/