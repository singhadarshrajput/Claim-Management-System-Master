/*CREATE TABLE claims(CID varchar(25), Status varchar(25), Description varchar(25), Remarks varchar(25), Claim_Amount decimal(10,2), hospitalId varchar(30),benefitId varchar(30),PolicyId varchar(20),MemberId varchar(20));*/

